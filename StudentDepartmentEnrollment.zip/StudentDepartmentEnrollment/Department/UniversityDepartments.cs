﻿using System;
using System.Collections.Generic;
using System.Text;
using ApplicationData;
using System.Collections.Generic;
using System.Linq;

namespace Department
{
    public class UniversityDepartments
    {

        List<DepartmentData> DepartmentList = new List<DepartmentData>();
        List<StudentData> StudentList = new List<StudentData>();
        List<FacultyData> FacultyList = new List<FacultyData>();
       
        public UniversityDepartments()
        {
            DepartmentList.Add(new DepartmentData(40, "System Design", 45635,FacultyList));
            DepartmentList.Add(new DepartmentData(50,"Computer Science", 45636, FacultyList));
            DepartmentList.Add(new DepartmentData(50,"Mathematics", 45637, FacultyList));
            DepartmentList.Add(new DepartmentData(40, "System Architecture", 45638, FacultyList));
            DepartmentList.Add(new DepartmentData(55,"Netwoking", 45639,FacultyList));
        
        }
        public void GetDepartments()
        {
            Console.WriteLine("Departmemts");
            foreach (var dpt in DepartmentList)
            {
               
                Console.WriteLine("No of Students:{0}, Department Name:{1}, Department code:{2}", dpt.NOS, dpt.departmentName, dpt.departmentID);
            }
        }
        public void ViewDepartments()
        {
            Console.WriteLine("Total Students");
            foreach (var dpt in DepartmentList)
            {

                Console.WriteLine("No of Students:{0}, Department Name:{1}", dpt.NOS, dpt.departmentName);
            }
        }
        public int[] Enroll(string name,int age,Guid id)
        {
            int n;
            
            Console.WriteLine("Departmemts Enrollment");
            Console.WriteLine("How Many Departments Do you Want To Select");
            n = Convert.ToInt32(Console.ReadLine());
            int[] depts = new int[n];
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter " +i+1  +" Department Code To Select");
               
                    int  na= Convert.ToInt32(Console.ReadLine());
                depts[i] = na;
             
            }
            if (CheckforDuplicates(depts))
            {
                Console.WriteLine("Error Occured in Department Enrollment");
                Enroll(name,age,id);
                return depts;
            }
            else
            {

                StudentList.Add(new StudentData(name, id, age, depts));
                return depts;
            }
            return depts;

        }
       
        public bool CheckforDuplicates(int[] array)
        {
           
                

               
                    var duplicates = array
                 .GroupBy(p => p)
                 .Where(g => g.Count() > 1)
                 .Select(g => g.Key);


                    return (duplicates.Count() > 0);
               
               

            
           
        }
    }
}

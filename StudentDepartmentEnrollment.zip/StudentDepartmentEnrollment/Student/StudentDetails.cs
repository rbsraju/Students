﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ApplicationData;
using Department;
using Faculty;

namespace Student
{

    /*   public interface IStudentDetails
       {
           public  void AddStudent();
           public void ViewStudent();

       }*/

    public class StudentDetails 
    {
        List<StudentData> StudentList = new List<StudentData>();
      
        private static UniversityDepartments UD = new UniversityDepartments();
        private static FacultyRegistation FR = new FacultyRegistation();
        public void AddStudent()
        {


            Console.WriteLine("\n ::::::::::Student Register Form::::::::::");
            Console.Write("\n Student Name:");
            var name = Console.ReadLine();
            Console.Write("\n Age:");
            int age = Convert.ToInt32(Console.ReadLine());
            Guid guid = System.Guid.NewGuid();

            UD.GetDepartments();
           int[] depts= UD.Enroll(name, age, guid);
           
            string[] facu=FR.Enroll(depts);
          
        

        }
      
        public void ViewStudent()
        {
            foreach (var std in StudentList)
            {
                Console.WriteLine("Student: {0},{1},{2}", std.Name, std.Age, std.StudentID);
            }
        }
        public bool CheckforDuplicates(string[] array)
        {
            var duplicates = array
             .GroupBy(p => p)
             .Where(g => g.Count() > 1)
             .Select(g => g.Key);


            return (duplicates.Count() > 0);

        }
    }
}

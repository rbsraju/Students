﻿using System;
using Student;
using Department;
namespace StudentEnrollment
{
    public class ApplicationForEnrollment
    {

       
        private static StudentDetails Studentobj = new StudentDetails();
        private static UniversityDepartments UD = new UniversityDepartments();

        static void Main(string[] args)
        { 
            
          
            Studentobj.AddStudent();
           
            UD.ViewDepartments();
        }
    }
}

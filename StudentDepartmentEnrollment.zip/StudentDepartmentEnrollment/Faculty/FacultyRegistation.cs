﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ApplicationData;

namespace Faculty
{
    public class FacultyRegistation
    {
        List<DepartmentData> DepartmentList = new List<DepartmentData>();
        List<FacultyData> FacultyList = new List<FacultyData>();
        public FacultyRegistation()
        {
            FacultyList.Add(new FacultyData("Jansi KR", "SRM", "Main","Good"));
            FacultyList.Add(new FacultyData("Raju", "SRM", "Main", "Excelent"));
            FacultyList.Add(new FacultyData("Bhas", "VIT", "Mech", "Excelent"));
            FacultyList.Add(new FacultyData("Srini", "VIT", "Mech", "good"));
        }
     
        public string[] Enroll(int[] depts)
        {
            int n;

            Console.WriteLine("Faculty Enrollment");
            
            n = depts.Length;
            string[] faculty = new string[n];
           for(int i = 0; i < n; i++)
            {
                Console.WriteLine("Department:"+depts[i]);
                foreach(var fc in FacultyList)
                {
                    Console.WriteLine("Faculty Name:{0}", fc.name);
                }
                faculty[i] = Console.ReadLine();

            }
            if (CheckforDuplicates(faculty))
            {
                Console.WriteLine("Error Occured in Faculty Enrollment");
                Enroll(depts);
                return null;
            }
            else
            {
                return faculty;
            }
            


        }
        public bool CheckforDuplicates(string[] array)
        {
            var duplicates = array
             .GroupBy(p => p)
             .Where(g => g.Count() > 1)
             .Select(g => g.Key);


            return (duplicates.Count() > 0);

        }
    }
}

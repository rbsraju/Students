﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationData
{
   public  class FacultyData
    {
       
        public string name;
        public string university;
        public string campus;
        public string description;
        /*  public List<FacultyData> faculty;*/



        public FacultyData(string name, string university, string campus, string description)
        {
            this.name = name;
            this.university = university;
            this.campus = campus;
            this.description = description;

        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string University
        {
            get { return university; }
            set { university = value; }
        }

        public string Campus
        {
            get { return campus; }
            set { campus = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationData
{
   public  class DepartmentData
    {
        public int NOS;
        public string departmentName;
        public int departmentID;
        public List<FacultyData> faculty;
      /*  public List<FacultyData> faculty;*/
        


        public DepartmentData(int NOS,string departmentName, int departmentID, List<FacultyData> faculty)
        {
            this.NOS = NOS;
            this.departmentName = departmentName;
            this.departmentID = departmentID;
            this.faculty = faculty;

        }
        public int No_Of_Students
        {
            get { return NOS; }
            set { NOS = value; }
        }
        public string DepartmentName
        {
            get { return departmentName; }
            set { departmentName = value; }
        }

        public int StudentID
        {
            get { return departmentID; }
            set { departmentID = value; }
        }
        public List<FacultyData> Faculty
        {
            get { return faculty; }
            set { faculty = value; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationData
{
    public class StudentData
    {
        public  string name;
        public Guid studentID;
        public int age;
        public int[] departments;


        public StudentData(string name, Guid studentID, int age, int[] departments)
        {
            this.name = name;
            this.studentID = studentID;
            this.age = age;
            this.departments = departments;


        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Guid StudentID
        {
            get { return studentID; }
            set { studentID = value; }
        }
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public int[] Departments
        {
            get { return departments; }
            set { departments = value; }
        }
    }
}
